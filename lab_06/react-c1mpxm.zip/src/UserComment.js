import React from 'react';

export default function UserComment(props) {
  return (
    <div
      style={{
        display: 'flex',
        marginTop: '20px',
      }}
      className="pic"
    >
      <img
        style={{
          width: '50px',
          height: '50px',
          borderRadius: '50px',
        }}
        src={props.src}
        alt={props.caption}
        className="pic"
      />
      <div
        style={{
          marginLeft: '10px',
          marginTop: '-15px',
          lineHeight: '5px',
        }}
        className="content"
      >
        <p
          style={{
            fontSize: '0.95em',
            color: 'darkslategray',
          }}
          className="name"
        >
          {props.caption}
        </p>
        <p>{props.comment}</p>
        <p
          style={{
            fontSize: '0.85em',
            color: 'darkgray',
          }}
          className="time"
        >
          {props.time}
        </p>
      </div>
    </div>
  );
}
