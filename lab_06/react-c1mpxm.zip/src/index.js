import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import UserComment from './UserComment.js';

// var creates variable that can be updated.
// const create a read-only variable
const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="body">
      <h1>L'APPART</h1>
      <p>
        French ·
        <a href="https://maps.apple.com/?address=Historic%20Core%20%E6%B4%9B%E6%9D%89%E7%9F%B6,%20CA%20%E7%BE%8E%E5%9B%BD&auid=6881845831853720439&ll=34.048812,-118.248311&lsp=7618&q=Historic%20Core&t=m">
          Historic Core, Los Angeles
        </a>
        · $$$
      </p>
      <button>
        <a href="https://www.air-food.com/">Website</a>
      </button>
      <hr />
      <p>
        <strong>Service option:</strong> Dine-in · Takeout · Delivery
      </p>
      <p>
        <strong>Address:</strong> 130 E 6th St, Los Angeles, CA 90014
      </p>
      <p>
        <strong>Hours: </strong>
      </p>
      <ul>
        <li>Sunday: 11AM - 2PM, 6-9PM</li>
        <li>Monday: Closed</li>
        <li>Tuedsay: Closed</li>
        <li>Wednesday: 6-9PM</li>
        <li>Thursday: 6-9PM</li>
        <li>Friday: 6-9PM</li>
        <li>Saturday: 6-9PM</li>
      </ul>
      <p>
        <strong>Phone:</strong> (213) 628-3158
      </p>
      <p>
        <strong>Reservation:</strong>{' '}
        <a href="https://www.air-food.com/">air-food.com</a>,{' '}
        <a href="https://www.opentable.com/r/lappart-los-angeles?ref=1068">
          opentable.com
        </a>
      </p>
      <hr />
      <p>
        <strong>Pictures: </strong>
      </p>
      <div className="img">
        <div className="imgd">
          <img
            src="https://www.air-food.com/wp-content/uploads/elementor/thumbs/Filet-Mignon-min-1-p4kw9zpsms4wnm3lmettc0wwx3ncdizf5rcr7r5vhc.jpg"
            alt="fm"
          />
          <h4>Filet Mignon</h4>
        </div>
        <div className="imgd">
          <img
            src="https://www.air-food.com/wp-content/uploads/elementor/thumbs/Risotto-min-p4kx0paouap8kpaungh5os9gm9zu3w0ttyqh5tk4o0.jpg"
            alt="ri"
          />
          <h4>Risotto</h4>
        </div>
        <div className="imgd">
          <img
            src="https://www.air-food.com/wp-content/uploads/elementor/thumbs/Saumon-min-1-p4ky1meha18olbo92ezmmgv8l40ufwla8p71r2tg9s.jpg"
            alt="bt"
          />
          <h4>Beef Tartar</h4>
        </div>
      </div>
      <hr />
      <h4>Reviews:</h4>
      <UserComment
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTySEVPbBxP5bezQve0ekErBhG7c8_DLq0GE-th5XWU9KyhI6Inbw_VSTMmhSiryUCypwc&usqp=CAU"
        caption="Lily"
        comment="Cozy, excellent food and service, authentic French staff"
        time="16:62"
      />
      <UserComment
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSon7UXXyxvoxfrD0brWchUB7kIU545JP7QtQ&usqp=CAU"
        caption="Mike"
        comment="Very authentic and refined French food — chefs and staff are all
        super legit, dishes are nuanced, and the vibe is nice!"
        time="a day ago"
      />
      <UserComment
        src="https://pub-static.fotor.com/assets/projects/pages/d5bdd0513a0740a8a38752dbc32586d0/fotor-03d1a91a0cec4542927f53c87e0599f6.jpg"
        caption="TJ P"
        comment="Cozy, excellent food and service, authentic French staff"
        time="3 days ago"
      />
      <div className="footer">
        <h2>
          @Lily Tan | <a href="mailto=tanlily@usc.edu">tanlily@usc.edu</a>
          ｜inspired by <a href="https://www.google.com/maps">@google map</a>
        </h2>
      </div>
    </div>
  </React.StrictMode>
);
