import React from 'react';
import { useState } from 'react';

export default function KanyeImg() {
  const [num, setNum] = useState(0);

  function handleNumPlus() {
    setNum(num + 1);
  }

  function handleNumMinus() {
    if (num > 0) {
      setNum(num - 1);
    }
  }

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 'auto',
        marginRight: 'auto',
      }}
      className="button"
    >
      <button
        onClick={() => {
          handleNumMinus();
        }}
        style={{
          height: '35px',
        }}
      >
        -
      </button>
      <p
        style={{
          marginTop: '8px',
        }}
      >
        {num}
      </p>
      <button
        onClick={() => {
          handleNumPlus();
        }}
        style={{
          height: '35px',
        }}
      >
        +
      </button>
    </div>
  );
}
