import React from 'react';
import { useState } from 'react';

export default function KanyeImg() {
  const [src, setSrc] = useState(
    'https://static.wixstatic.com/media/16345c_9bb35b40dce84c16af7ed2152af60a7a~mv2.jpg/v1/fill/w_1000,h_1000,al_c,q_85,usm_0.66_1.00_0.01/16345c_9bb35b40dce84c16af7ed2152af60a7a~mv2.jpg'
  );

  const [alt, setAlt] = useState('Another 13');

  const [cap, setCap] = useState('Another 13');

  function handleImageChange(newSrc, newAlt) {
    console.log('Changing the image');
    setSrc(newSrc);
    setAlt(newAlt);
    setCap(newAlt);
  }

  return (
    <div>
      <button
        onClick={() => {
          handleImageChange(
            'https://static.wixstatic.com/media/16345c_9bb35b40dce84c16af7ed2152af60a7a~mv2.jpg/v1/fill/w_1000,h_1000,al_c,q_85,usm_0.66_1.00_0.01/16345c_9bb35b40dce84c16af7ed2152af60a7a~mv2.jpg',
            'Another 13'
          );
        }}
      >
        Another 13'
      </button>
      <button
        onClick={() => {
          handleImageChange(
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi50-mjhvcFWJ3XsgJrpaRH07HnWMeW5CxqDvyZc71lXLNRYla8EOLHFzFxtJSqm9oi9M&usqp=CAU',
            'En Passant'
          );
        }}
      >
        En Passant
      </button>
      <button
        onClick={() => {
          handleImageChange(
            'https://lifestyleperfume.am/images/product/1604731559-fic.jpg',
            'Fico di Amalfi'
          );
        }}
      >
        Fico di Amalfi
      </button>
      <button
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/1200x/ec/8e/ec/ec8eec0a2e2b79ea9d011baa953b744b.jpg',
            'Luna'
          );
        }}
      >
        Luna
      </button>
      <button
        onClick={() => {
          handleImageChange(
            'https://www.maxaroma.com/images/product-story/story-images/UP7340032806168_one.png?verP=1688183446',
            'Gypsy Water'
          );
        }}
      >
        Gypsy Water
      </button>
      <button
        onClick={() => {
          handleImageChange(
            'https://image-cdn.hypb.st/https%3A%2F%2Fhypebeast.com%2Fwp-content%2Fblogs.dir%2F6%2Ffiles%2F2022%2F10%2Fhermes-beauty-cabriole-perfume-for-children-1.jpg?cbr=1&q=90',
            'Cabriole'
          );
        }}
      >
        Cabriole
      </button>
      <img src={src} alt={alt} />
      <p>{cap}</p>
    </div>
  );
}
