import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function homePage() {
  const [question, setQuestions] = useState([]);

  function handleQuestions(p) {
    const newArr = [...question, p];
    // Use setQuestions to update the state with the new array
    setQuestions(newArr);
  }

  return (
    <div className="page">
      <h1>Wecome to the Tarot Generator</h1>
      <div className="otherPage">
        <Circle p="tarot card" navigatePath="/" />
        <Circle p="Spread Introducation" navigatePath="/ArrayIntro" />
      </div>
      <div className="acknowledgement">
        <h3>*Acknowledgement before divination</h3>
        <p>
          Welcome to our Tarot Card Random Generator! This tool is designed for
          entertainment and exploratory purposes only. Remember, it's just a bit
          of fun and should not be considered a substitute for actual tarot
          divination or professional advice. The cards drawn here are randomly
          generated and don't reflect any mystical or supernatural insight. We
          encourage you to enjoy this experience with a light heart and an open
          mind, but please don't make significant life decisions based on the
          results. Let's explore the fascinating world of tarot together, with
          curiosity and a playful spirit!
        </p>
      </div>
      <div className="arrayButton">
        <p>* Please select one of the following category to start</p>
        <ArraySelection p="Love" navigatePath="/Love" />
        <ArraySelection p="Working" navigatePath="/Work" />
        <ArraySelection p="Daily life" navigatePath="/DailyLife" />
      </div>
      <div className="Your questions">
        <p>Your asked questions:</p>
        <ul>
          <li>
            1. Love: 0. The Fool, X. The Wheel of Fortune, XVIII. The Moon
          </li>
          <li>2. ...</li>
          <li>3. ...</li>
        </ul>
      </div>
    </div>
  );

  function Circle(props) {
    const navigate = useNavigate();

    const handleClick = () => {
      navigate(props.navigatePath); // Navigate to the path provided in props
    };
    return (
      <button
        style={{
          width: '200px', // Width of the oval
          height: '100px', // Height of the oval
          backgroundColor: '#5EC5D4', // Color of the oval
          boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
          borderRadius: '50%', // Makes the corners fully rounded
          border: '0px',
          margin: '10px',
          display: 'inline-block',
          textAlign: 'center',
          lineHeight: '100px',
        }}
        onClick={handleClick}
        // task: onClick - to the other page
        // task 2: style/shade of the oval
        // task 3: font and color of the text
      >
        {props.p}
      </button>
    );
  }
  function ArraySelection(props) {
    const navigate = useNavigate();

    const handleClick = () => {
      navigate(props.navigatePath); // Navigate to the path provided in props
    };
    return (
      <button
        style={{
          width: '200px',
          height: '100px',
          backgroundColor: '#5EC5D4', // Color of the rectangle
          boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
          borderRadius: '20px',
          border: '0px',
          margin: '10px',
          display: 'inline-block',
          textAlign: 'center',
          lineHeight: '100px',
        }}
        onClick={handleClick}
        // task: onClick - to the other page/
        // task 2: style/shade of the oval
        // task 3: font and color of the text
      >
        {props.p}
      </button>
    );
  }
}
