import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function homePage(props) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(props.navigatePath); // Navigate to the path provided in props
  };
  return (
    <div
      style={{
        display: 'inline-block',
      }}
    >
      <button
        style={{
          width: '200px',
          height: '50px',
          backgroundColor: '#5EC5D4', // Color of the rectangle
          boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
          border: '0px',
          margin: '10px',
          display: 'inline-block',
          textAlign: 'center',
          lineHeight: '50px',
        }}
        onClick={handleClick}
      >
        {props.p}
      </button>
    </div>
  );
}
