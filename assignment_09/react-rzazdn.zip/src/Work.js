import React from 'react';
import { useState } from 'react';
import Another from './Another.js';
import Shuffle from './Shuffle.js';

export default function homePage() {
  const [cardName, setCardName] = useState('Sample Card');
  const [keyWord, setKeyword] = useState('Sample Card');
  const [description, setDescription] = useState('Sample Description');
  const [src, setSrc] = useState(
    'https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg'
  );
  return (
    <div className="page">
      <h1>Welcome to the Work Spread</h1>
      <div
        className="cards"
        style={{
          textAlign: 'center',
        }}
      >
        <div
          className="3"
          style={{
            textAlign: 'center',
          }}
        >
          <Card
            src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
            alt="3"
          />
        </div>
        <Card
          src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
          alt="1"
        />
        <Card
          src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
          alt="2"
        />
        <div
          className="4n5"
          style={{
            marginLeft: '100px',
            display: 'inline-block',
          }}
        >
          <Card
            src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
            alt="4"
          />
          <Card
            src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
            alt="5"
          />
        </div>
      </div>
      <p>*1: You as you are.</p>
      <p>*2: Are you on the correct path</p>
      <p>*3: What is the main obstacle</p>
      <p>*4: What is helping me</p>
      <p>*5: How can progress be made</p>
      <div
        lassName="button"
        style={{
          textAlign: 'center',
        }}
      >
        <Another p="Make another divination" navigatePath="/" />
        <Shuffle p="Shuffle the card" />
      </div>
      <CardIntro />
    </div>
  );
  function Card(props) {
    return (
      <div
        style={{
          display: 'inline-block',
          textAlign: 'center',
        }}
      >
        <img
          src={props.src}
          alt={props.caption}
          style={{
            width: '100px',
            margin: '10px',
          }}
        />
        <p>{props.alt}</p>
      </div>
    );
  }
  function CardIntro() {
    return (
      <div
        style={{
          display: 'inline-block',
        }}
      >
        <div
          className="img"
          style={{
            display: 'inline-block',
          }}
        >
          <img
            src={src}
            alt={cardName}
            style={{
              display: 'inline-block',
              width: '100px',
              margin: '10px',
            }}
          />
        </div>
        <div
          className="description"
          style={{
            display: 'inline-block',
            margin: '20px',
          }}
        >
          <p>{'Card name: ' + cardName}</p>
          <p>{'Key words: ' + keyWord}</p>
          <p>{'Description: ' + description}</p>
        </div>
      </div>
    );
  }
}
