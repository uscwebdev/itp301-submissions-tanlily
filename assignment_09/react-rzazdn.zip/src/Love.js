import React from 'react';
import { useState } from 'react';
import Another from './Another.js';
import Shuffle from './Shuffle.js';

export default function homePage() {
  const [cardName, setCardName] = useState('Sample Card');
  const [keyWord, setKeyword] = useState('Sample Card');
  const [description, setDescription] = useState('Sample Description');
  const [src, setSrc] = useState(
    'https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg'
  );
  return (
    <div className="page">
      <h1>Welcome to the Love Card Spread</h1>
      <div
        className="cards"
        style={{
          textAlign: 'center',
        }}
      >
        <Card
          src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
          alt="1"
        />
        <Card
          src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
          alt="2"
        />
        <Card
          src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
          alt="3"
        />
        <div
          className="4"
          style={{
            display: 'inline-block',
            marginLeft: '100px',
          }}
        >
          <Card
            src="https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg"
            alt="4"
          />
        </div>
      </div>
      <p>*1, 2, 3: Your feeling to your lover</p>
      <p>*4: Long term out come of the relationship</p>
      <div
        className="button"
        style={{
          textAlign: 'center',
        }}
      >
        <Another p="Make another divination" navigatePath="/" />
        <Shuffle p="Shuffle the card" />
      </div>
      <CardIntro />
    </div>
  );
  function Card(props) {
    return (
      <div
        style={{
          display: 'inline-block',
        }}
      >
        <img
          src={props.src}
          alt={props.caption}
          style={{
            width: '100px',
            margin: '10px',
          }}
        />
        <p>{props.alt}</p>
      </div>
    );
  }
  function CardIntro() {
    return (
      <div
        style={{
          display: 'inline-block',
        }}
      >
        <div
          className="img"
          style={{
            display: 'inline-block',
          }}
        >
          <img
            src={src}
            alt={cardName}
            style={{
              display: 'inline-block',
              width: '100px',
              margin: '10px',
            }}
          />
        </div>
        <div
          className="description"
          style={{
            display: 'inline-block',
            margin: '20px',
          }}
        >
          <p>{'Card name: ' + cardName}</p>
          <p>{'Key words: ' + keyWord}</p>
          <p>{'Description: ' + description}</p>
        </div>
      </div>
    );
  }
}
