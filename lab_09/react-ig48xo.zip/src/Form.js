import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fullname, setFullname] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [commentL, setCommentL] = useState(0);
  const [condition, setCondition] = useState(false);

  const [fullnameError, setFullnameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [password2Error, setPassword2Error] = useState();
  const [emailError, setEmailError] = useState();
  const [contactError, setContactError] = useState();
  const [commentError, setCommentError] = useState();
  const [conditionError, setConditionError] = useState();

  function handleRegister(e) {
    // e.preventDefault();
    // console.log('form submitted');

    var foundError = false;

    /*
      Username cannot be empty.
      Username cannot contain uppercase letters.
    */
    if (fullname.length == 0) {
      // Username is empty.
      foundError = true;
      setFullnameError('Full name cannot be empty.');
    } else if (fullname.indexOf(' ') < 0) {
      foundError = true;
      setFullnameError(
        'Username Must be full name (have a space between words)'
      );
    } else {
      // No errors.
      setFullnameError('');
    }

    if (password.length == 0) {
      // Username is empty.
      foundError = true;
      setPasswordError('Password cannot be empty.');
    } else if (password.length > 0 && password < 5) {
      foundError = true;
      setPasswordError('Password must contain at least 5 characters');
    } else if (!(/[A-Z]/.test(password) && /[a-z]/.test(password))) {
      foundError = true;
      setPasswordError(
        'Password must contain both uppercase and lowercase characters'
      );
    } else {
      // No errors.
      setPasswordError('');
    }

    if (password2.length == 0) {
      // Username is empty.
      foundError = true;
      setPassword2Error('Password confirmation cannot be empty.');
    } else if (password2.length != 0 && password2 != password) {
      // Username contains uppercase characters.
      foundError = true;
      setPassword2Error('Password does not match, please type it again');
    } else {
      // No errors.
      setPassword2Error('');
    }

    if (email.length != 0 && email.indexOf('@') == -1) {
      // Username is empty.
      foundError = true;
      setEmailError('Email must contain an @ character.');
    } else {
      // No errors.
      setEmailError('');
    }

    if (email.length == 0 && phone.length == 0) {
      foundError = true;
      setContactError('Must select to fill in one contact');
    } else {
      setContactError('');
    }

    if (comment.length > 100) {
      foundError = true;
      setCommentError('Comment cannot exceed 100 characters');
    } else {
      setCommentError('');
    }

    if (condition == false) {
      foundError = true;
      setConditionError('You must check the Terms and Conditions');
    } else {
      setConditionError('');
    }

    if (foundError == true) {
      e.preventDefault();
    } else {
      alert('The form was successfully submitted.');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          Validation rules:
          <ul>
            <li>Username cannot be empty.</li>
            <li>Username Must be full name (have a space between words)</li>
            <li>Password cannot be empty.</li>
            <li>Password must contain at least 5 characters.</li>
            <li>Password Must contain uppercase and lowercase characters.</li>
            <li>Confirm password must match the password field.</li>
            <li>Either email or phone number must be provided.</li>
            <li>Comment cannot exceed 100 characters.</li>
            <li>Terms & Conditions must be accepted (checked).</li>
          </ul>
        </div>
        <div className="col-12">
          <form onSubmit={handleRegister}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setFullname(e.currentTarget.value);
                  }}
                  value={fullname}
                />
                <small id="username-error" className="form-text text-danger">
                  {fullnameError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPassword(e.currentTarget.value);
                  }}
                  value={password}
                />

                <small id="password-error" className="form-text text-danger">
                  {passwordError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPassword2(e.currentTarget.value);
                  }}
                  value={password2}
                />
                <small id="password-error" className="form-text text-danger">
                  {password2Error}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setEmail(e.currentTarget.value);
                      }}
                      value={email}
                    />
                    <small
                      id="username-error"
                      className="form-text text-danger"
                    >
                      {emailError}
                    </small>
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setPhone(e.currentTarget.value);
                      }}
                      value={phone}
                    />
                  </div>
                  <small id="password-error" className="form-text text-danger">
                    {contactError}
                  </small>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setComment(e.currentTarget.value);
                    setCommentL(e.currentTarget.value.length);
                  }}
                  value={comment}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {commentL} / 100
                  {commentError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    onChange={() => {
                      setCondition(!condition);
                    }}
                    checked={condition}
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                  <small id="subscribe-error" className="form-text text-danger">
                    {conditionError}
                  </small>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
