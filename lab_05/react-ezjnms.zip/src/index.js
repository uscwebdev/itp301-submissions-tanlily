import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

// var creates variable that can be updated.
// const create a read-only variable
const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Lily Tan</h1>
    <a href="tanlily@usc.edu">tanlily@usc.edu</a>
    <p id="favcolor">Favorite color: Corn flower blue</p>
    <p>
      Favorite Website: <a href="https://chat.openai.com/">ChatGPT</a>
    </p>
    <p>Class Enrolled: </p>
    <ul>
      <li>LAW 401</li>
      <li>ITP 301</li>
      <li>ITP 489</li>
      <li>ITP 487</li>
    </ul>

    <hr />

    {/* <div className="thumbnail"> 
      <img
        src="https://campusactivities.usc.edu/wp-content/uploads/sites/3/2021/07/PrimShield-Mono_SmallUse_CardOnTrans_RGB-removebg-preview.png"
        alt="usc logo"
      />
      <h4> Image heading</h4>
      <p>Caption for the image</p>
    </div> */}
    <Activity />
  </React.StrictMode>
);

function Activity() {
  return (
    <div className="activity">
      <img
        src="https://www.si.com/.image/t_share/MjAwNDc3OTQzNTA2NDEyOTIw/1-lead-photo.jpg"
        alt="golf"
      />
      <h4>Golf</h4>
    </div>
  );
}
