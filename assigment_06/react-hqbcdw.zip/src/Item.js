import React from 'react';

export default function Item(props) {
  return (
    <div
      style={{
        //display: 'inlineBlock',
        width: '25%',
        textAlign: 'center',
      }}
      className="item"
    >
      <img
        style={{
          display: 'block',
          border: '1px solid #ddd',
          borderRadius: '4px',
          padding: '5px',
          width: '80%',
          height: '350px',
          marginLeft: 'auto',
          marginRight: 'auto',
        }}
        src={props.src}
        alt={props.caption}
        className="pic"
      />
      <p
        style={{
          fontSize: '1.05em',
        }}
      >
        {props.caption}
      </p>
      <p
        style={{
          fontSize: '0.90em',
          color: 'darkgray',
          marginTop: '-10px',
        }}
      >
        {'$' + props.price}
      </p>
    </div>
  );
}
