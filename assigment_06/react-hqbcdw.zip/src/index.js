import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Item from './Item.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>My Cart</h1>
    </div>

    <div className="products">
      <Item
        src="https://beautinow.com/wp-content/uploads/2023/08/FMEnPassantBox.jpg"
        caption="Frederic Malle En Passant"
        price="225"
      />
      <Item
        src="https://my-test-11.slatic.net/p/8fecf1a2eef6c54281eb0eafa3fce4ce.jpg"
        caption="Lelabo Anther 13"
        price="230"
      />
      <Item
        src="https://joebrand.com/cdn/shop/products/BaccaratArtboard4.jpg?v=1665076660&width=320"
        caption="MFK Baccarat Rouge 540 EDP"
        price="325"
      />
      <Item
        src="https://www.guerlain.com/dw/image/v2/BDCZ_PRD/on/demandware.static/-/Sites-GSA_master_catalog/default/dw791ae48d/primary_packshot_3/2023/Fragrances/PEX/PEX-MUGUET_PRIMARY-VISUAL_PDP.jpg?sw=655&sh=655"
        caption="Guerlain Muguet"
        price="750"
      />
    </div>

    <div className="footer">
      <h2>
        @Lily Tan | <a href="mailto=tanlily@usc.edu">tanlily@usc.edu</a>
      </h2>
    </div>
  </React.StrictMode>
);
