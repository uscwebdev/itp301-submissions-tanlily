import React from 'react';
import { useState } from 'react';

export default function shuffle(props) {
  return (
    <div
      style={{
        display: 'inline-block',
        textAlign: 'center',
      }}
    >
      <button
        style={{
          width: '200px',
          height: '50px',
          backgroundColor: '#5EC5D4', // Color of the rectangle
          boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
          border: '0px',
          margin: '10px',
          textAlign: 'center',
          lineHeight: '50px',
        }}
      >
        {props.p}
      </button>
    </div>
  );
}
