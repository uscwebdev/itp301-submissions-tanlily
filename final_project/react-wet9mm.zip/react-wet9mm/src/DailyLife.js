import React from 'react';
import { useState } from 'react';
import Another from './Another.js';
import TarotCards from './TarotCard';

export default function homePage() {
  const [cardName, setCardName] = useState('Sample Card');
  const [keyWord, setKeyword] = useState('Sample Card');
  const [description, setDescription] = useState('Sample Description');
  const [src, setSrc] = useState(
    'https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg'
  );
  var results = JSON.parse(localStorage.getItem('life'));
  const [num, setnum] = useState([0, 0, 0]);
  const selectedCard1 = TarotCards[num[0]];
  const selectedCard2 = TarotCards[num[1]];
  const selectedCard3 = TarotCards[num[2]];
  return (
    <div className="page">
      <h1>Welcome to the Daily Life Spread</h1>
      <div
        className="cards"
        style={{
          textAlign: 'center',
        }}
      >
        <Card
          src={selectedCard1.imageSrc}
          alt={selectedCard1.name}
          introduction={selectedCard1.introduction}
          keywords={selectedCard1.keywords}
        />
        <Card
          src={selectedCard2.imageSrc}
          alt={selectedCard2.name}
          introduction={selectedCard2.introduction}
          keywords={selectedCard2.keywords}
        />
        <Card
          src={selectedCard3.imageSrc}
          alt={selectedCard3.name}
          introduction={selectedCard3.introduction}
          keywords={selectedCard3.keywords}
        />
      </div>
      <p>*1: Past</p>
      <p>*2: Present</p>
      <p>*3: Future</p>
      <div
        className="button"
        style={{
          textAlign: 'center',
        }}
      >
        <Another p="Make another divination" navigatePath="/" />
        <Shuffle p="Shuffle the card" />
      </div>
      <h4>
        *After shuffle, you can click on the image of each card to learn about a
        detailed description of that card
      </h4>
      <CardIntro />
      <div id="footer">
        <p className = "footerT">
          @Lily Tan | <a href="mailto=tanlily@usc.edu">tanlily@usc.edu</a>
        </p>
      </div>
    </div>
  );
  function Card(props) {
    return (
      <div
        style={{
          display: 'inline-block',
          textAlign: 'center',
        }}
      >
        <img
          src={props.src}
          alt={props.caption}
          style={{
            width: '100px',
            margin: '10px',
          }}
          onClick={() => {
            setSrc(props.src);
            setCardName(props.alt);
            setDescription(props.introduction);
            setKeyword(props.keywords);
          }}
        />
        <p>{props.alt}</p>
      </div>
    );
  }
  function CardIntro() {
    return (
      <div
        style={{
          display: 'inline-block',
          width: '600px',
        }}
      >
        <div
          className="img"
          style={{
            display: 'inline-block',
          }}
        >
          <img
            src={src}
            alt={cardName}
            style={{
              display: 'inline-block',
              width: '100px',
              margin: '10px',
            }}
          />
        </div>
        <div
          className="description"
          style={{
            display: 'inline-block',
            margin: '20px',
          }}
        >
          <p>{'Card name: ' + cardName}</p>
          <p>{'Key words: ' + keyWord}</p>
          <p>{'Description: ' + description}</p>
        </div>
      </div>
    );
  }
  function Shuffle(props) {
    return (
      <div
        style={{
          display: 'inline-block',
          textAlign: 'center',
        }}
      >
        <button
          style={{
            width: '200px',
            height: '50px',
            backgroundColor: '#5EC5D4', // Color of the rectangle
            boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
            border: '0px',
            margin: '10px',
            textAlign: 'center',
            lineHeight: '50px',
          }}
          onClick={() => {
            var unique = RandomNumberGenerator();
            var r = results;
            var i =
              TarotCards[unique[0]].name +
              ', ' +
              TarotCards[unique[1]].name +
              ', ' +
              TarotCards[unique[2]].name +
              ', ' +
              TarotCards[unique[3]].name;
            r = [...r, i];
            console.log(r);
            results = r;
            localStorage.setItem('life', JSON.stringify(r));
            console.log(localStorage.getItem('life'));
            setSrc(
              'https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg'
            );
            setCardName('Sample Card');
            setDescription('Sample Card Description');
            setKeyword('Sample Keywords');
          }}
        >
          {props.p}
        </button>
      </div>
    );
  }
  function RandomNumberGenerator() {
    const uniqueNumbers = [];

    // Generate four non-repetitive random numbers
    while (uniqueNumbers.length < 4) {
      const randomNumber = Math.floor(Math.random() * 22) + 1;
      if (!uniqueNumbers.includes(randomNumber)) {
        uniqueNumbers.push(randomNumber);
      }
    }
    setnum(uniqueNumbers);
    console.log(uniqueNumbers);
    return uniqueNumbers;
  }
}
