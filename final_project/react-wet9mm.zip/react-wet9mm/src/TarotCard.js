const tarotCards = [
  {
    imageSrc:
      'https://images.squarespace-cdn.com/content/v1/6282048f3ddae806d695b4b8/1652902864243-IZZNPSQWKB9E50IF39VH/one-card-tarot.jpg',
    name: 'Default',
    keywords: 'Default, The back of the card',
    introduction: 'This is the default image display the back of the card',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/07/the-fool-tarot-card.jpg',
    name: '0.The Fool',
    keywords: 'New beginnings, Spontaneity',
    introduction:
      'The Fool card represents new beginnings, spontaneity, and a sense of adventure. It signifies stepping into the unknown with enthusiasm and an open heart.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/03/the-magician-tarot-card.jpg',
    name: 'I.The Magician',
    keywords: 'Manifestation, Power',
    introduction:
      'The Magician card symbolizes the power of manifestation and the ability to turn your dreams into reality. It represents creativity, confidence, and the use of your skills to achieve your goals.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2019/11/the-high-priestess-tarot-card.jpg',
    name: 'II.The High Priestess',
    keywords: 'Intuition, Secrets',
    introduction:
      'The High Priestess card embodies intuition, wisdom, and the uncovering of hidden truths. It represents a deep connection to the subconscious mind and spiritual insight.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2023/10/The-Empress-tarot-card.jpg',
    name: 'III.The Empress',
    keywords: 'Abundance, Fertility',
    introduction:
      'The Empress card signifies abundance, fertility, and nurturing energy. It represents the power of creation, growth, and the beauty of nature.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2019/08/the-emperor-tarot-card.jpg',
    name: 'IV.The Emperor',
    keywords: 'Authority, Leadership',
    introduction:
      'The Emperor card symbolizes authority, leadership, and structure. It represents a strong, confident, and organized approach to achieving goals.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2019/10/the-hierophant-tarot.jpg',
    name: 'V.The Hierophant',
    keywords: 'Tradition, Spirituality',
    introduction:
      'The Hierophant card represents tradition, spirituality, and guidance from higher powers. It signifies a connection to established beliefs and spiritual teachings.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/07/the-lovers-tarot-card.jpg',
    name: 'VI.The Lovers',
    keywords: 'Relationships, Choices',
    introduction:
      'The Lovers card symbolizes love, relationships, and choices. It represents a significant romantic or emotional connection and the need to make decisions from the heart.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/07/the-chariot-tarot-card.jpg',
    name: 'VII.The Chariot',
    keywords: 'Victory, Willpower',
    introduction:
      'The Chariot card signifies victory, willpower, and determination. It represents a focused and disciplined approach to overcoming obstacles and achieving success.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/07/strength-tarot-card.jpg',
    name: 'VIII.Strength',
    keywords: 'Courage, Inner power',
    introduction:
      'Strength card embodies strength, courage, and inner power. It represents the ability to face challenges with grace, compassion, and inner fortitude.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/09/the-hermit-tarot-card-meaning-rider-waite.jpg',
    name: 'IX.The Hermit',
    keywords: 'Solitude, Inner guidance',
    introduction:
      'The Hermit card symbolizes solitude, inner guidance, and introspection. It signifies a period of self-discovery and seeking answers within.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/wheel-of-fortune-tarot-card.jpg',
    name: 'X.Wheel of Fortune',
    keywords: 'Change, Destiny',
    introduction:
      'Wheel of Fortune card represents change, destiny, and cycles of life. It symbolizes the ever-changing nature of existence and the importance of embracing the ups and downs of life.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/justice-tarot-card-meaning.jpg',
    name: 'XI.Justice',
    keywords: 'Fairness, Balance',
    introduction:
      'Justice card embodies fairness, balance, and truth. It represents the need for impartiality, ethical decision-making, and accountability.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2019/09/the-hanged-man-tarot-card-1.jpg',
    name: 'XII.The Hanged Man',
    keywords: 'Surrender, Letting go',
    introduction:
      'The Hanged Man card signifies surrender, letting go, and seeing things from a new perspective. It represents the willingness to release control and gain insight through sacrifice.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/death-tarot-card-image.jpg',
    name: 'XIII.Death',
    keywords: 'Transformation, Rebirth',
    introduction:
      'Death card symbolizes transformation, rebirth, and the end of one chapter to start another. It represents the natural cycles of life and the need for letting go of the old to welcome the new.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/temperance-card-in-tarot.jpg',
    name: 'XIV.Temperance',
    keywords: 'Balance, Harmony',
    introduction:
      'Temperance card embodies balance, harmony, and moderation. It represents the blending of opposites and finding the middle path to achieve peace and equilibrium.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-devil-card-upright.jpg',
    name: 'XV.The Devil',
    keywords: 'Temptation, Materialism',
    introduction:
      'The Devil card signifies temptation, materialism, and bondage. It represents the struggle with earthly desires and the need to break free from unhealthy attachments.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-tower-tarot-card-meaning.jpg',
    name: 'XVI.The Tower',
    keywords: 'Sudden change, Chaos',
    introduction:
      'The Tower card represents sudden change, chaos, and upheaval. It signifies a significant and unexpected disruption that can lead to transformation and growth.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-star-card-in-tarot.jpg',
    name: 'XVII.The Star',
    keywords: 'Hope, Inspiration',
    introduction:
      'The Star card symbolizes hope, inspiration, and healing. It represents a guiding light in the darkness and the promise of better times ahead.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-moon-tarot-card-original.jpg',
    name: 'XVIII.The Moon',
    keywords: 'Illusion, Intuition',
    introduction:
      'The Moon card embodies illusion, intuition, and the subconscious mind. It signifies the need to trust your instincts and navigate the mysteries of the unseen.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-sun-card-tarot-reading.jpg',
    name: 'XIX.The Sun',
    keywords: 'Joy, Success',
    introduction:
      "The Sun card signifies joy, success, and enlightenment. It represents a period of happiness, clarity, and the warmth of the sun's energy.",
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/judgement-tarot-card-design.jpg',
    name: 'XX.Judgment',
    keywords: 'Reckoning, Redemption',
    introduction:
      'Judgment card represents reckoning, redemption, and a call to action. It signifies a moment of reflection and the opportunity to make amends and move forward.',
  },
  {
    imageSrc:
      'https://www.alittlesparkofjoy.com/wp-content/uploads/2020/10/the-world-tarot-card.jpg',
    name: 'XXI.The World',
    keywords: 'Completion, Fulfillment',
    introduction:
      'The World card symbolizes completion, fulfillment, and achievement. It represents the successful culmination of a journey and the realization of your goals and potential.',
  },
];

export default tarotCards;
