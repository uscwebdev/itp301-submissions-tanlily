import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function homePage() {
  return (
    <div className="page">
      <h1>Array Introduction</h1>
      <div className="otherPage">
        <Circle p="tarot card" navigatePath="/" />
        <Circle p="Spread Introducation" navigatePath="/ArrayIntro" />
      </div>
      <div className="Array Intro">
        <ArrayIntro
          src="https://github.com/uscwebdev/itp301-submissions-tanlily/blob/gh-pages/final_proj_img/love.png?raw=true"
          alt="Love Life Tarot Spread"
          p={
            <div>
              <p>1, 2, 3: Your feeling to your lover</p>
              <p>4: Long term out come of the relationship</p>
            </div>
          }
        />
        <ArrayIntro
          src="https://github.com/uscwebdev/itp301-submissions-tanlily/blob/gh-pages/final_proj_img/working.png?raw=true"
          alt="Working Tarot Spread"
          p={
            <div>
              <p>1: You as you are.</p>
              <p>2: Are you on the correct path</p>
              <p>3: What is the main obstacle</p>
              <p>4: What is helping me</p>
              <p>5: How can progress be made</p>
            </div>
          }
        />
        <ArrayIntro
          src="https://github.com/uscwebdev/itp301-submissions-tanlily/blob/gh-pages/final_proj_img/dailylife.png?raw=true"
          alt="Daily Life Tarot Spread"
          p={
            <div>
              <p>1: Past</p>
              <p>2: Present</p>
              <p>3: Future</p>
            </div>
          }
        />
      </div>
      <div id="footer">
        <p className="footerT">
          @Lily Tan | <a href="mailto=tanlily@usc.edu">tanlily@usc.edu</a>
        </p>
      </div>
    </div>
  );
  function Circle(props) {
    const navigate = useNavigate();

    const handleClick = () => {
      navigate(props.navigatePath); // Navigate to the path provided in props
    };
    return (
      <button
        style={{
          width: '200px', // Width of the oval
          height: '100px', // Height of the oval
          backgroundColor: '#5EC5D4', // Color of the oval
          boxShadow: '5px 5px 10px rgba(173, 216, 230, 0.5)',
          borderRadius: '50%', // Makes the corners fully rounded
          border: '0px',
          margin: '10px',
          display: 'inline-block',
          textAlign: 'center',
          lineHeight: '100px',
        }}
        onClick={handleClick}
        // task: onClick - to the other page
        // task 2: style/shade of the oval
        // task 3: font and color of the text
      >
        {props.p}
      </button>
    );
  }
  function ArrayIntro(props) {
    return (
      <div>
        <div
          style={{
            display: 'inline-block',
          }}
        >
          <img
            src={props.src}
            alt={props.caption}
            style={{
              width: '300px',
              marginTop: '-100px',
              marginRight: '50px',
            }}
          />
        </div>
        <div
          className="description"
          style={{
            display: 'inline-block',
          }}
        >
          <h4>{props.alt}</h4>
          <p>Explanation</p>
          <p>{props.p}</p>
        </div>
      </div>
    );
  }
}
