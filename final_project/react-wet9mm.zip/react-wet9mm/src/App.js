import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';

import HomePage from './HomePage.js';
import Love from './Love.js';
import Work from './Work.js';
import DailyLife from './DailyLife.js';
import ArrayIntro from './ArrayIntro.js';

function App() {
  var empty = [];
  localStorage.setItem('love', JSON.stringify(empty));
  localStorage.setItem('work', JSON.stringify(empty));
  localStorage.setItem('life', JSON.stringify(empty));

  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/Love" element={<Love />} />
          <Route path="/Work" element={<Work />} />
          <Route path="/DailyLife" element={<DailyLife />} />
          <Route path="/ArrayIntro" element={<ArrayIntro />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
