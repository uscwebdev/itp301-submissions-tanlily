import React from 'react';
import Button from './Button.js';
import { useState } from 'react';

export default function Item(props) {
  const [subtotal, setSubtotal] = useState(0);
  function subtotaLPlus(i) {
    var plus = parseInt(i);
    setSubtotal(subtotal + plus);
  }
  function subtotalMinus(i) {
    var minus = parseInt(i);
    setSubtotal(subtotal - minus);
  }

  return (
    <div>
      <Button
        src="https://beautinow.com/wp-content/uploads/2023/08/FMEnPassantBox.jpg"
        caption="Frederic Malle En Passant"
        price="225"
        parentPlus={subtotaLPlus}
        parentMinus={subtotalMinus}
      />

      <Button
        src="https://my-test-11.slatic.net/p/8fecf1a2eef6c54281eb0eafa3fce4ce.jpg"
        caption="Lelabo Anther 13"
        price="230"
        parentPlus={subtotaLPlus}
        parentMinus={subtotalMinus}
      />

      <Button
        src="https://joebrand.com/cdn/shop/products/BaccaratArtboard4.jpg?v=1665076660&width=320"
        caption="MFK Baccarat Rouge 540 EDP"
        price="325"
        parentPlus={subtotaLPlus}
        parentMinus={subtotalMinus}
      />

      <Button
        src="https://www.guerlain.com/dw/image/v2/BDCZ_PRD/on/demandware.static/-/Sites-GSA_master_catalog/default/dw791ae48d/primary_packshot_3/2023/Fragrances/PEX/PEX-MUGUET_PRIMARY-VISUAL_PDP.jpg?sw=655&sh=655"
        caption="Guerlain Muguet"
        price="750"
        parentPlus={subtotaLPlus}
        parentMinus={subtotalMinus}
      />
      <div className="subtotal">
        <strong>
          <p
            style={{
              fontSize: '1.5em',
            }}
          >
            Subtotal: ${subtotal}
          </p>
        </strong>
      </div>
    </div>
  );
}
