import React from 'react';
import { useState } from 'react';

export default function Button(props) {
  const [num, setNum] = useState(0);

  function handleNumPlus() {
    setNum(num + 1);
  }

  function handleNumMinus() {
    if (num > 0) {
      setNum(num - 1);
    }
  }
  return (
    <div>
      <div
        style={{
          //display: 'inlineBlock',
          //width: '25%',
          textAlign: 'center',
        }}
        className="item"
      >
        <img
          style={{
            display: 'block',
            border: '1px solid #ddd',
            borderRadius: '4px',
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
          src={props.src}
          alt={props.caption}
          className="pic"
        />
        <p
          style={{
            fontSize: '1.05em',
          }}
        >
          {props.caption}
        </p>
        <p
          style={{
            fontSize: '0.90em',
            color: 'darkgray',
            marginTop: '-10px',
          }}
        >
          {'$' + props.price}
        </p>
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginLeft: 'auto',
          marginRight: 'auto',
        }}
        className="button"
      >
        <button
          onClick={() => {
            handleNumMinus();
            if (num > 0) {
              props.parentMinus(props.price);
            }
          }}
          style={{
            height: '35px',
          }}
        >
          -
        </button>
        <p
          style={{
            marginTop: '8px',
          }}
        >
          {num}
        </p>
        <button
          onClick={() => {
            handleNumPlus();
            props.parentPlus(props.price);
          }}
          style={{
            height: '35px',
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
