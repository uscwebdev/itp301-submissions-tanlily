import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Item from './Item.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>My Cart</h1>
    </div>

    <div className="products">
      <Item />
    </div>

    <div className="footer">
      <h2>
        @Lily Tan | <a href="mailto=tanlily@usc.edu">tanlily@usc.edu</a>
      </h2>
    </div>
  </React.StrictMode>
);
